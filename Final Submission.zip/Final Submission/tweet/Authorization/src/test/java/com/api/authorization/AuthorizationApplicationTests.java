package com.api.authorization;


import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class AuthorizationApplicationTests {

	@Test
	public void contextLoads() {
	}

	@Test
	public void mainTest() {
		AuthorizationApplication.main(new String[] {});
	}
}
